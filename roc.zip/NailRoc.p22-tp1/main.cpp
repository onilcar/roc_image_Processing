#include "fonction.h"
#include <stdio.h>
#include <stdlib.h>
#include <opencv2/opencv.hpp>


using namespace cv;
using namespace std;




int main( int argc, char** argv )
{
	int choose=0, choose0=0, type, number;
	char ImageName[100];
	Mat image_orig, histo_orig, profil_orig, trace_orig;
	Mat image_modi, histo_modi, profil_modi, trace_modi;
	Mat curve;
	std::string pstion;

    void drawLine(Mat image, std::string type, int number, std::string renamePhoto);// Fonction pour tracer le trait sur l'image
    void IntensityProfile(cv::Mat image, std::string type, int number, std::string renamePhoto);// Fonction qui détermine le profil d'intensite



            do{
                cout<<"\n\n";
                cout << "                              ***** Profil d'intensité *****";
                cout<<"\n";
                cout<<"                             ----------&&----------                    ";
                cout<<"\n";
                cout<<"          ********** Amélioration du contraste d'une image **********     "<<endl;
                cout<<"\n   ---------------------------------------------------- \n";
                cout << "1-- Pour le profil d'intensite"<<endl;
                cout << "2-- Pour la modification de contraste"<<endl;
                cout << "3-- Quitter"<<endl;


                cout << " \n Veuillez faire un choix: ";
                cin  >> choose0;
                cout<<"\n";

                    if((choose0!=1)&&(choose0!=2)&&(choose0!=3)){
                        system("clear");
                        cout << "\n     Veuillez choisir un numero valide"<<endl;
                        }
                        else{

                switch (choose0)
                {
                    case 1:
                    {
                            Mat inputImage; // Variable pour stocker l'image
                            string CurveName, renamePhoto; //Pour nomer l'image trace et la courbe du profile d'intensite

                            cout << "\n Donner le nom de votre l'image : ";
                            cin  >> ImageName;
                            cout<<"\n";

                            inputImage = imread(ImageName); // chargement de l'image



                        if(argc!=1){
                               // system("clear");
                                cout << "   Veuillez entrer seulement le nom du fichier"<< endl;
                        }
                        else
                        {
                            if(!inputImage.data){
                            system("clear");
                            cout<<"     Veuillez fournir un fichier image valide  \n"<<endl;
                            cvDestroyAllWindows();
                        }
                        else{
                            cout << "\n  Quel type de profil voulez-vous?\n";
                            cout << " Entrer line pour une ligne et column pour une colonne : ";
                            cin  >> pstion;

                            cout << "\n Entrer le nombre de ligne/colonne : ";
                            cin  >> number;

                            if((pstion=="Line")||(pstion=="Column")||(pstion=="line")||(pstion=="column"))
                            {

                            int check=0;
                            // Vérification du numero spécifié par l'utilisateur
                            if(((pstion=="Line")||(pstion=="line"))&&(inputImage.rows < number)){
                                cout<<"Veuillez entrer un numero de ligne inférieur à "<< inputImage.rows<<endl;
                                check =1;
                            cvDestroyAllWindows();
                                }
                            else if(((pstion=="Column")||(pstion=="line"))&&(inputImage.cols < number)){
                            cout <<"Veuillez entrer un numero de colonne inférieur à "<<inputImage.cols<<endl;
                            check = 1;
                            cvDestroyAllWindows();
                                }
                            if(check==0){
                            cout<<"\n";
                                cout<<"Nomer la courbe du profil d'intensité, presser entrer & Renomer l'image tracé:"<<endl;
                                cin>>CurveName;
                                cin>>renamePhoto;

                                IntensityProfile(inputImage, pstion, number, CurveName);// Tracé de la courbe du profil d'intensité

                                drawLine(inputImage, pstion, number, renamePhoto);// Tracé sur l'image

                                waitKey(0);

                                cvDestroyAllWindows();
                                system("clear");

                                }
                            }
                            else
                            {
                            cout<<"Incorrect Syntaxe \n"<<endl; // syntaxe incorrecte
                            }
                        }
                    }
            break;}

            case 2:
            {
                system("clear");
                if(argc!=1){
                cout << "Veuillez entrer seulement le nom du fichier main"<< endl;
                }
                else{
                    do{
                    cout<<"\n\n";
                    cout << "************Amélioration du contraste d'une image ************"<<endl;
                    cout<<"\n ------------------------------------------------------------- \n";
                    cout << "  Vous avez cinq options dans le menu.Veuillez choisir un numero."<<endl;
                    cout << "1-- Pour faire une modification avec fonction linéaire à 3 points."<<endl;
                    cout << "2-- Pour faire une modification (non linéaire) avec la correction gamma."<<endl;
                    cout << "3-- Pour faire une modification avec fonction linéaire avec saturation."<<endl;
                    cout << "4-- Retouner au menu principal."<<endl;
                    cout << "5-- Quiter."<<endl;

                        cout << " \n Veuillez faire un choix: ";
                        cin  >> choose;

                        //(choose=getchar()==(isalpha(choose)))

                      if(((choose !=1)&&(choose!=2)&&(choose!=3)&&(choose!=4)&&(choose!=5))){
                        cout << "\n Veuillez choisir un numero valide"<<endl;
                        }
                        else{
                            if(choose == 5){
                            cout << "Bye !!!"<< endl;
                            return 0;
                            }
                            else if(choose == 4){
                            system("clear");
                            cvDestroyAllWindows();
                            break;

                        }
                        else{
                            cout << "\n Donner le nom de votre l'image : ";
                            cin  >> ImageName;
                            cout<<"\n";
                            image_orig = imread(ImageName); // chargement de l'image
                            if(!image_orig.data){
                            system("clear");
                            cout << "\n Veuillez fournir une image valide"<<endl;
                        }
                        else{
                            cout << "\n Quel type de profil voulez-vous?\n";
                            cout<< " Entrer 1 pour une ligne et 2 pour une colonne : ";
                            cin >> type;
                            cout <<"\n";
                            cout << " Donner le numero de la ligne ou de la colonne choisie : ";
                            cin >> number;
                            cout <<"\n";

                            switch (choose)
                            {
                                case 1: // Modification fonction linéaire à deux points
                                {
                                    Point FirstPoint, Point2, Point3;//int abscisse1, ordonnee1, abscisse2, ordonnee2;

                                    // Collecte des informations spécifiques à la fonction linéaires
                                    cout << "Modification avec fonction linéaire à deux points"<<endl;
                                    cout << " Veuillez renseigner les coordonnées des trois points"<<endl;
                                    cout << "Premier Point"<<endl;
                                    cout << "Abscisse : ";
                                    cin  >> FirstPoint.x;
                                    cout << "Ordonnée : ";
                                    cin  >> FirstPoint.y;

                                    cout <<"\n";
                                    cout << "Deuxieme Point"<<endl;
                                    cout << "Abscisse : ";
                                    cin  >> Point2.x;
                                    cout << "Ordonnée : ";
                                    cin  >> Point2.y;

                                    cout <<"\n";
                                    cout << "Troisieme Point"<<endl;
                                    cout << "Abscisse :  ";
                                    cin  >> Point3.x;
                                    cout << "Ordonnée :  ";
                                    cin  >> Point3.y;

                                    // Traitement de l'image selon les données receuillies
                                    image_modi = fonctionLineaire3Points(image_orig,FirstPoint, Point2, Point3);
                                    curve = courbeFonctionLineaire3Points(FirstPoint, Point2, Point3);

                                    // Affichage de la courbe de la fonction
                                    imshow( "Fonction linéaire à deux points", curve );

                                    // Enregistrement de l'histogramme orginal dans un fichier image
                                    if(!imwrite("fonction_lineaire.png", curve))
									cout<<"Erreur lors de l'enregistrement"<<endl;
                                    break;
                                }
                                case 2: // Modification avec correction gamma
                                {
                                    float gamma;
                                    // Collecte des informations spécifiques à la fonction linéaires
                                    cout << "Modification avec la correction gamma"<<endl;
                                    cout << " Veuillez renseigner la valeur de gamma"<<endl;
                                    cin  >> gamma;

                                    // Traitement de l'image selon la valeur de gamma
                                    image_modi = correctionGamma(image_orig,gamma);
                                    curve = courbeFonctionGamma(gamma);

                                    // Affichage de la courbe de la fonction
                                    imshow( "Gamma Function", curve );
                                    // Enregistrement de l'histogramme orginal dans un fichier image
                                    if(!imwrite("Gamma_function.png", curve))
									cout<<"Erreur lors de l'enregistrement"<<endl;
                                break;
                                }

                                case 3: // Modification linaire avec saturation
                                {
                                    Point FirstPoint, Point2;
                                    // Collecte des informations spécifiques à la fonction linéaires
                                    cout << "Modification avec la fonction linéaire de saturation"<<endl;
                                    cout << " Veuillez renseigner les abscisses des deux points"<<endl;

                                    cout << "Le minimum $ ";
                                    cin  >> FirstPoint.x;
                                    FirstPoint.y = 0;

                                    cout << "Le maximum $ ";
                                    cin  >> Point2.x;
                                    Point2.y = 255;

                                    // Traitement de l'image selon les deux points fournis
                                    image_modi = fonctionLineaireSaturation(image_orig,FirstPoint, Point2);
                                    curve = courbeFonctionLineaireSaturation(FirstPoint, Point2);

                                    // Affichage de la courbe de la fonction
                                    imshow( "Linear saturation function", curve );
                                    // Enregistrement de l'histogramme orginal dans un fichier image
                                    if(!imwrite("Saturation_function.png", curve))
									cout<<"Erreur lors de l'enregistrement"<<endl;
								break;
                                }default: cout<<"Error";
                            }

                            //Affichabe donnée originale
                            profil_orig = ProfilIntensiteImage(image_orig, type, number);

                            trace_orig = tracerTrait(image_orig, type, number);

                            histo_orig = histogramme(image_orig);

                            //Affichage de l'histogramme original
                            imshow("Histogram of original image", histo_orig );
                            // Enregistrement de l'histogramme orginal dans un fichier image
                            if(!imwrite("Histogram_of_original_image.png", histo_orig))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            // Affichage du profl original
                            imshow( "Original intensity profile", profil_orig );
                            // Enregistrement du profil original dans un fichier image
                            if(!imwrite("original_intensity_profile.png", profil_orig))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            // Affichage de l'image originale avec le trait du profil
                            imshow( "Original image", trace_orig );
                            // Enregistrement de l'image originale avec trait dans un fichier image
                            if(!imwrite("original_image_.png", trace_orig))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            //Affichage des données modifiées
                            profil_modi = ProfilIntensiteImage(image_modi, type, number);

                            trace_modi = tracerTrait(image_modi, type, number);

                            histo_modi = histogramme(image_modi);

                            //Affichage de l'histogramme modifié
                            imshow("Histogram of the image modified", histo_modi );
                            // Enregistrement de l'histogramme modifié dans un fichier image
                            if(!imwrite("histogram_of_image_modified.png", histo_modi))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            // Affichage du profl modifié
                            imshow( "Intensité profile modified", profil_modi );
                            // Enregistrement du profil modifié dans un fichier image
                            if(!imwrite("Intensity_profile_modified.png", profil_modi))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            // Affichage de l'image modifiée avec le trait du profil
                            imshow( "Image modified ", trace_modi );
                            // Enregistrement du l'image modifiée avec le trait du profil
                            if(!imwrite("image_modified.png", trace_modi))
                                cout<<"Erreur lors de l'enregistrement"<<endl;

                            waitKey(0);// Attente d'une action de l'utilisateur

                            cvDestroyAllWindows(); // Destruction des fenêtres
                            system("clear");

                            }
                        }
                    }

                }while(choose!=5);

            }

            break;}
            case 3 : { cout << "Au revoir !!!"<< endl; return 0;
            break;}

            }
        }

    }while(choose0!=3);

}
